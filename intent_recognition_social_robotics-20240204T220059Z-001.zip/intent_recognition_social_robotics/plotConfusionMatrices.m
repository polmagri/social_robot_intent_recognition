clear all; clc; close all; tic;
warning off;

%% declaring variables
% to decide the dataset
dataBaseArray=["BabyEarsDatabase.mat", "KismetDatabase.mat"];


%% decision process
possibleAlgorithms = {'BT', 'KNN3', 'KNN12', 'KNN80', 'LinSVM', 'QuadSVM'};
algorithm = menu('Which algorithm do you want to test?', possibleAlgorithms);
KNN3 = 1; KNN80 = 2; LinSVM = 3; QuadSVM = 4;

possibleApproaches = {'Intra Corpus', 'Cross Corpus', 'Pooling'};
approach = menu('Which approach do you want to use?', possibleApproaches);
IC = 1; CC = 2; P = 3;

switch approach
    case IC
        possibleDatabase = {'BE2with', 'BE2without','BE3with','BE3without',...
            'K2with','K2without','K3with','K3without'};
        
        databaseChoice = menu('Which database do you want to use?', possibleDatabase);
        
        if databaseChoice <= 4
            i_train_test = 1;
        else
            i_train_test = 2;
        end
        
        if databaseChoice == 1 || databaseChoice == 2 || databaseChoice == 5 || databaseChoice == 6
            numberOfClasses = 2;
        else
            numberOfClasses = 3;
        end
        
        if mod(databaseChoice,2) == 1 %odd number
            unvoicedYN = 1;
        else
            unvoicedYN = 2;
        end
        
        % preparing the data
        
        % loading the database
        load(strcat('.\data\', dataBaseArray(i_train_test)));
        setOfDataArray={{features2Unv, features2noUnv},{features3Unv, features3noUnv}};
        database = setOfDataArray{numberOfClasses - 1}{unvoicedYN};
        
        [Training, Test] = Random_extraction(length(database), 0.6);
        TrainingDataset=[]; TestDataset=[];
        for l = 1:length(database)
            if ismember(l,Training)
                TrainingDataset = [TrainingDataset; database(l,:)];
            end
            if ismember(l,Test)
                TestDataset = [TestDataset; database(l,:)];
            end
        end
        
    case CC
        possibleDatabase = {'BEonK2with','BEonK2without','BEonK3with',...
            'BEonK3without','KonBE2with','KonBE2without','KonBE3with',...
            'KonBE3without'};
        
        databaseChoice = menu('Which database do you want to use?', possibleDatabase);
        
        if databaseChoice <= 4
            i_train = 1; i_test = 2;
        else
            i_train = 2; i_test = 1;
        end
        
        if databaseChoice == 1 || databaseChoice == 2 || databaseChoice == 5 || databaseChoice == 6
            numberOfClasses = 2;
        else
            numberOfClasses = 3;
        end
        
        if mod(databaseChoice,2) == 1 %odd number
            unvoicedYN = 1;
        else
            unvoicedYN = 2;
        end
        
        % preparing the data
        load(strcat('.\data\', dataBaseArray(i_train)));
        setOfDataArray={{features2Unv, features2noUnv},{features3Unv, features3noUnv}};
        databaseTraining = setOfDataArray{numberOfClasses - 1}{unvoicedYN};
        
        load(strcat('.\data\', dataBaseArray(i_test)));
        setOfDataArray={{features2Unv, features2noUnv},{features3Unv, features3noUnv}};
        databaseTest = setOfDataArray{numberOfClasses - 1}{unvoicedYN};
        
        % preparing the data of Train
        [Training, Test] = Random_extraction(length(databaseTraining), 0.6);
        TrainingDataset=[];
        for l = 1:length(databaseTraining)
            if ismember(l,Training)
                TrainingDataset = [TrainingDataset; databaseTraining(l,:)];
            end
            %                     if ismember(l,Test)
            %                         TestDataset = [TestDataset; database(l,:)];
            %                     end
        end
        
        % preparing the data of Test
        [Training, Test] = Random_extraction(length(databaseTest), 0.6);
        TestDataset=[];
        for l = 1:length(databaseTest)
            %                     if ismember(l,Training)
            %                         TrainingDataset = [TrainingDataset; database(l,:)];
            %                     end
            if ismember(l,Test)
                TestDataset = [TestDataset; databaseTest(l,:)];
            end
        end
        
    case P
       
        possibleDatabase = {'BE&KonBE2with','BE&KonBE2without','BE&KonBE3with',...
            'BE&KonBE3without','BE&KonK2with','BE&KonK2without','BE&KonK3with',...
            'BE&KonK3without'};
        
        databaseChoice = menu('Which database do you want to use?', possibleDatabase);
        
        if databaseChoice <= 4
            i_trainTest = 1; i_trainOnly = 2;
        else
            i_trainTest = 2; i_trainOnly = 1;
        end
        
        if databaseChoice == 1 || databaseChoice == 2 || databaseChoice == 5 || databaseChoice == 6
            numberOfClasses = 2;
        else
            numberOfClasses = 3;
        end
        
        if mod(databaseChoice,2) == 1 %odd number
            unvoicedYN = 1;
        else
            unvoicedYN = 2;
        end
        
        % preparing the data
        load(strcat('.\data\', dataBaseArray(i_trainTest)));
        setOfDataArray={{features2Unv, features2noUnv},{features3Unv, features3noUnv}};
        databaseTrainingTest = setOfDataArray{numberOfClasses-1}{unvoicedYN};
        
        load(strcat('.\data\', dataBaseArray(i_trainOnly)));
        setOfDataArray={{features2Unv, features2noUnv},{features3Unv, features3noUnv}};
        databaseTrainingOnly = setOfDataArray{numberOfClasses-1}{unvoicedYN};
        
        % preparing the data of the database that will train and test the
        % algorithm
        [Training, Test] = Random_extraction(length(databaseTrainingTest), 0.6);
        TrainingDataset=[]; TestDataset=[];
        for l = 1:length(databaseTrainingTest)
            if ismember(l,Training)
                TrainingDataset = [TrainingDataset; databaseTrainingTest(l,:)];
            end
            if ismember(l,Test)
                TestDataset = [TestDataset; databaseTrainingTest(l,:)];
            end
        end
        
        % preparing the data of database that will add training data
        [Training, Test] = Random_extraction(length(databaseTrainingOnly), 0.6);
        
        for l = 1:length(databaseTrainingOnly)
            if ismember(l,Training)
                TrainingDataset = [TrainingDataset; databaseTrainingOnly(l,:)];
            end
            %                     if ismember(l,Test)
            %                         TestDataset = [TestDataset; databaseTest(l,:)];
            %                     end
        end
        
end

%% using the algorithms
switch algorithm
    case KNN3
        % using KNN 3
        classifier=trainClassifier_KNN3(TrainingDataset);
    case KNN80
        % using KNN 80
        classifier=trainClassifier_KNN80(TrainingDataset);
    case LinSVM
        % using SVM Linear
        classifier=trainClassifier_SVMLin(TrainingDataset);
    case QuadSVM
        % using SVM Quadratic
        classifier=trainClassifier_SVMQuad(TrainingDataset);
end
ypredicted=classifier.predictFcn(TestDataset(:,1:end-1));
figure; plotconfusion(categorical(TestDataset(:,end)'),categorical(ypredicted'));
title(strcat(possibleAlgorithms{algorithm}, ' / ' , possibleApproaches(approach), ' / ', possibleDatabase(databaseChoice)));

figure; cm = confusionchart(categorical(TestDataset(:,end)'),categorical(ypredicted'));
cm.RowSummary = 'row-normalized';
cm.ColumnSummary = 'column-normalized';
title(strcat(possibleAlgorithms{algorithm}, ' / ' , possibleApproaches(approach), ' / ', possibleDatabase(databaseChoice)));
toc