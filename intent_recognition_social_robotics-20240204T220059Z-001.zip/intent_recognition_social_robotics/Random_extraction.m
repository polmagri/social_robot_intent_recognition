function [Training, Test] = Random_extraction(n, perc)

Training=[];
Test=[];

div = n*perc;

%assign random element to training
while length(Training) < div
    num=randi(n);
    if ismember(num,Training)
        continue
    else
        Training=[Training num];
    end
end

% sorting in ascending order
Training = sort(Training);

%assign the remaining element for Test
for i=1:n
    if ismember(i,Training)
        continue
    else
        Test=[Test i];
end

end

