% The script returns the following structures:
% - F0
% - EN
% which are structures with 3 fields --> Data [Table], Label and Subject

% Directory where data are located
data_dir_Kismet = '.\data\Kismet_data';

f0_files = dir([data_dir_Kismet '\*.f0']);
en_files = dir([data_dir_Kismet '\*.en']);


f0_files_path = fullfile({f0_files.folder},{f0_files.name})';
en_files_path = fullfile({en_files.folder},{en_files.name})';


% .f0 files
f0_data = cell(length(f0_files_path),1);
f0_labels = cell(length(f0_files_path),1);
f0_subjects = cell(length(f0_files_path),1);
for i = 1:length(f0_files_path)
    [f0_data{i}, f0_labels{i}, f0_subjects{i}] = import_f0_k(char(f0_files_path(i)));
end

F0 = struct('Data', f0_data, 'Label', f0_labels, 'Subject', f0_subjects);

% .en files
en_data = cell(length(en_files_path),1);
en_labels = cell(length(en_files_path),1);
en_subjects = cell(length(en_files_path),1);
for i = 1:length(en_files_path)
    [en_data{i}, en_labels{i}, en_subjects{i}] = import_en_k(char(en_files_path(i)));
end

EN = struct('Data', en_data, 'Label', en_labels, 'Subject', en_subjects);



clearvars -except F0 EN 