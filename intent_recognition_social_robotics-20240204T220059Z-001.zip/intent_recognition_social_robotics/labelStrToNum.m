function labelNumber = labelStrToNum(labelString)

%% decoding the label
if strcmp(labelString,'ap') %% approval
   labelNumber=1; 
elseif strcmp(labelString, 'pr') || strcmp(labelString, 'pw') %% prohibition
    labelNumber=2; 
elseif strcmp(labelString, 'at') %% attention
    labelNumber=3;
end
end

